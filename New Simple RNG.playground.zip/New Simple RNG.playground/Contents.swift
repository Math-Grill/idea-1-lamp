//: Playground - noun:  a place where people can play
// DON'T Delete past this line will mess-up the above text !!
// It turns into line one !!
// line 1 is  " //:  Text "
// the colon after the // is the key to the large white text


//  import Cocoa   // commented out don't seem to make a difference ??


print("Hello World")  // Classic First Program - Hello World

var string = "Hello, World 2"
print("test 1 + 2 = \(1 + 2) ", string )
// - - - - - End of first program - - - - -



//  - - -  New Random Number Generation Function !!  - - -
var NewRNG = 0
var TempRNG = 0

var m_z = Int.random(in: 18000 ..< 65535)  //  Seems to work as a RSG = ? =
var m_w = Int.random(in: 18000 ..< 65535)  //  = Random Seed Generator !! =

func RNG() -> Int  {
    m_z = 36969 * (m_z & 65535) + (m_z >> 16)
    m_w = 18000 * (m_w & 65535) + (m_w >> 16)
    TempRNG = (m_z << 16) + m_w
    NewRNG = TempRNG >> (32 + 8 + 3)   //  shifts the number down to 4 bits
    return  NewRNG    // It generates numbers from 1 to 18 'NOW' I think ?
}

//  - - -  printing loop calls the RNG() function - - -
for _ in 0..<10 {
    print("RNG()= \(RNG()), NewRNG = \(NewRNG), TempRNG = ", TempRNG)
}
//  - - -  End of printing loop  - - -
//  - - -  End of New Random Number Generation Function  !!  - - -



// = = =  Picking Random Numbers Between x & y  = = =
print("\n", "For next loop & do while loop", "\n")
var x = 2    // x & y are the lower and upper limits for m  with-in 4 bits
var y = 12

var m = 0
for _ in 1...5 {
    var rng = false    // Reset rng for next do while loop
    var c = 0
    repeat {       // = = = while loops up to here !! = = =
        c += 1
        m = RNG()  // calling the RND() function above to get a new random number; 4 bits
        print("", m, "-do loop count=", c)
        if (x <= m) && (m <= y) {   // this works for 4 bits RNG() as above
            rng = true              // set rng true and exit with desired number 'm'
            print( rng, m )         // got the desired number now = 'm' = check !!
            print("")               // print a blank line to seperate while loops
        }   // = end if =
    } while rng == false  // while if statement fails the repeat loop continues !!
}        // = = = End For loop = = =
// = = = Got the while loop finding numbers between x and y inclusive = = =
print("End of Do While loop & For next loop")
print(" - - - ") ; print("")
// = = = End of Picking Random Numbers Between x & y  = = =



class SomeClass {
    // class definition goes here "Basics for a Class"
}



// = = =  = =

//  = = = Experiment with Random Numbers = = =
//  - - - from Swift Language 4.1 prog manual  - - - page 542, 544

protocol RandomNumberGenerator {   // One protocol for RNG Class function below
    func random() ->  Double
}
// ... was causing an error below ... ADDED protocol RNG above ... error gone !
class LinearCongruentialGenerator: RandomNumberGenerator {
    var lastRandom =   42.0   // 42.0 was orginal number,  2a - hex
    let m =  1399680.0         // 139968.0   222c0  Google "Binary Number Converter"
    let a =  3877.0           //   3877.0    0f25
    let c =  29573.0          //  29573.0    7385 - hex
    func random() -> Double {
        lastRandom = ((lastRandom * a + c).truncatingRemainder(dividingBy:m))
        return lastRandom / m
    }
}       //  ... End of Class ...
// Generates numbers between 0 and 1, 15 digits long ? maybe not ??
//  0.000...1 to 0.999...9  I think ??
// set loop to 100 get variation in length shorter - longer
let generator = LinearCongruentialGenerator()
print("Here's a random number: \(generator.random())")
// Prints "Here's a random number: 0.37464991998171" = Not any more !!
// print("rng \(random())") // error usse of unresolved identifer random
print("And another one: \(generator.random())")
// Prints "And another one: 0.729023776863283”
var total = 0         // you can't use an integer in for loop below !!
var totals = 0.0
for i in 0...10 {
    totals = generator.random()
    // need a way to trip it over in time so it
    // starts at a different place each time its used by a person ?? but how ??
    //  print(totals * 1)  // multiplying by tens shifts the decimal point
    // dam Xcode won't iterate the print, whoops it down at the bottom of page !!
    total += i
// }
print(totals)
// print(total)
}
// Excerpt From: Apple Inc. “The Swift Programming Language (Swift 4.1).” iBooks.
// https://itunes.apple.com/ca/book/the-swift-programming-language-swift-4-1/id881256329?mt=11



// = = = = =

//  use bit shifting  >>  <<  to encode and decode values within other data types
var  pink: UInt32 = 0xcc6699  // UnSigned Interger 32 bits long, only using 24 bits
var redComponent = (pink & 0xFF0000) >> 16  // redComponent is 0xCC, or 204
var greenComponent = (pink & 0x00FF00) >> 8 // greenComponent is 0x66, or 102
var blueComponent = pink & 0x0000FF         // blueComponent is 0x99, or 153



// = = =  Simple Random Number Generator  = = =
//class TestClass {  // I'm doing somethimg wrong with the class structure ??

// I'm beginning to wonder if it should be in a class ??
// That a Function is better 'one generator' many calls
// - tried to wrap it in a class structure -- get errors
// - this is the same algorithm as above in function  RNG() diff names for var !
var Nresult = 0
var result =  0
//   var mz = 11         //  mz and mw = seed numbers for RNG program
var mz = Int.random(in: 18000 ..< 65535)  // = = = seem to be working = = = !!!
//    var mw = 11          //  making mz and mw = 0  output is all zero's
var mw = Int.random(in: 18000 ..< 65535)
//  Int.random  seems to generate new seeds !! Yes it works as seed !!!
for _ in 100...109  {    // 250 - 100 = 151 iterations of the - for in - loop -
    
    mz = 36969 * (mz & 65535) + (mz >> 16)
    mw = 18000 * (mw & 65535) + (mw >> 16)
    result = (mz << 16) + mw
    
    Nresult = result >> (32 + 8 + 3)  // truncates the number to 4 bits 0 - 17 ??
    // I think it is a signed number - ? - shrug -
    // and not a binary number being translated - ? -
    // +0, 0, -0, all count me thinks (0 - 15 + 2)
    
    print(" Nresult = \(Nresult)  - result =  \(result)")
    // - - -  see below for printout - Ok :)  - - -
}
// - - - End of - for loop - - -
//}
// = = =  End TestClass class  = = =



//  What’s new in Swift       = I think it's Swift 4.2 =
//  WWDC 2018 - session 401   = Apple Developer Video !!!

// var rng =  Int.random(in: 2 ..< 12)
// Used it in the above code  !!!  Makes for a good seed generator  !!!

for _ in 100...109 {
    let rng =  Int.random(in: 2 ..< 12)
   // print(rng)
    let fl = Float.random(in: 2 ..< 12)
    print(fl, "-", rng)
}
// = = =  The above is a new RNG using Swift .random generators !!
// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =



// = = = = = = = = = = = = =
// = = = Some Notes !! = = =
// = = = = = = = = = = = = =

// - -  Simple Random Number Generation from "CodeProject.com" (I Googled it!)
// - -  Google "Random Number Generator code" look for "Code Project" easy :))
// - -  org program for Simple Random Number Generation ... function below ...
// - -  I think it is written in C code it doesn't say - I commented it out !
/*
 private static uint  GetUint()
 {
 m_z = 36969 * (m_z & 65535) + (m_z >> 16);
 m_w = 18000 * (m_w & 65535) + (m_w >> 16);
 return (m_z << 16) + m_w;
 }
 */
// - - - 65535 is 2^16 in Binary numbers - - - need 32 bits for multiplying
// - - - a 32 bit unsigned number is - UInt32 - in Swift !! - - -


//  - - - example of calling function - - -
/*
 public static double  GetUniform()
 {
 //  0 <= u < 2^32
 uint u = GetUint();
 //  The Magic Number below is  1/(2^32 + 2) ...
 // The result is strictly between  0 and 1  ...
 return (u + 1.0) * 2.328306435454494e-10;
 }
 */
// - - -  end of calling function !! - - -
// = =  End of Simple Random Number Generator from Code Project  = = =
// - -  Using the code suggests  SetSeed()  or  SetSeedFromSystemTime()
// - -  as functions to setup the seed number initially upon start-up
// - - - - -  End of Simple Random Number Generation  - - - - -



// = = = = =

// - - - www.somebits.com/weblog/tech/appleNTP.html is - - -
// - - - address for below article from Google search - - -
// - - - for  time.apple.com  look-up - - -
// - - - NTP = Network Time Protocol ...
/*
 Apple's NTP service
 I love NTP, the magic Internet protocol that keeps computer clocks synchronized.
 One of the nice things Apple does is run an NTP service for all their computers.
 That's how your Mac always knows the right time. Here are some notes on what
 they do. My American MacOS 10.3.9 box has the following /private/etc/ntp.conf:
 
 server time.apple.com minpoll 12 maxpoll 17
 
 That means my Mac asks time.apple.com for the time somewhere between once an
 hour and once every day and a half. That's less often than usual for NTP,
 presumably an accuracy / scalability tradeoff.
 
 time.apple.com currently resolves to 4 IP addresses,
 17.254.0.26, .27, .28, and .31. All of them seem to be in San Jose, California.
 .26 is the most accurate clock (stratum 2), the others are just behind at
 stratum 3.
 
 Using ntpdc you can find out where .27 gets its time from. They're well
 synchronized, talking to several stratum 1 clocks. They poll each of those
 every 128 seconds, aggressive but maybe appropriate for such a well-used clock.
 They sync around the world, and also run services in Europe and Asia for their
 clients.
 */





