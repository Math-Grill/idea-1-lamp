//: Playground - noun:  a place where people can play
// DON'T Delete past this line will mess-up the above text !!
// It turns into line one !!
// line 1 is  " //:  Text "
// the colon after the // is the key to the large white text


//  import Cocoa   // commented out don't seem to make a difference ??


print("Hello World")  // Classic First Program - Hello World

var string = "Hello, World 2"
print("test 1 + 2 = \(1 + 2) ", string )
// - - - - - End of first program - - - - -



//  - - -  New Random Number Generation Function !!  - - -  RNG() -> Int
var NewRNG = 0
var TempRNG = 0

var m_z = Int.random(in: 18000 ..< 65535)  //  Seems to work as a RSG = ? =
var m_w = Int.random(in: 18000 ..< 65535)  //  = Random Seed Generator !! =

func RNG() -> Int  {
    m_z = 36969 * (m_z & 65535) + (m_z >> 16)
    m_w = 18000 * (m_w & 65535) + (m_w >> 16)
    TempRNG = (m_z << 16) + m_w
    NewRNG = TempRNG >> (32 + 8 + 3)   //  shifts the number down to 4 bits
    return  NewRNG    // It generates numbers from 1 to 18 'NOW' I think ?
}

//  - - -  printing loop calls the RNG() function - - - above !!
for _ in 0..<1 {
    print("RNG()= \(RNG()), NewRNG = \(NewRNG), TempRNG = ", TempRNG)
}
//  - - -  End of printing loop  - - -
//  - - -  End of New Random Number Generation Function  !!  - - -



// = = =  Picking Random Numbers Between x & y  = = =
// print("\n", "For next loop & do while loop", "\n")
var x = 1    // x & y are the lower and upper limits for m  with-in 4 bits
var y = 10   // 1 - 10 for testing !!

var m = 0
func RNGT() -> Int {
//for _ in 1..<2 {
    var rng = false    // Reset rng for next do while loop
    var c = 0
    repeat {       // = = = while loops up to here !! = = =
        c += 1
        m = RNG()  // calling the RND() function above to get a new random number; 4 bits
     //   print("", m, "-do loop count=", c)
        if (x <= m) && (m <= y) {   // this works for 4 bits RNG() as above
            rng = true              // set rng true and exit with desired number 'm'
      //      print( rng, m )         // got the desired number now = 'm' = check !!
     //       print("")               // print a blank line to seperate while loops
        }   // = end if =
    } while rng == false  // while if statement fails the repeat loop continues !!
//}        // = = = End For loop = = =
    
  return m
}  // end RNGTest function !!
// = = = Got the while loop finding numbers between x and y inclusive = = =
// print("End of Do While loop & For next loop", m)
// print(" - - - ") ; print("")
// = = = End of Picking Random Numbers Between x & y  = = =



class SomeClass {
    // class definition goes here "Basics for a Class"
}



// = = =  = =



// = = =  Simple Random Number Generator  = = =
//class TestClass {  // I'm doing somethimg wrong with the class structure ??

// I'm beginning to wonder if it should be in a class ??
// That a Function is better 'one generator' many calls
// - tried to wrap it in a class structure -- get errors
// - this is the same algorithm as above in function  RNG() diff names for var !
var Nresult = 0
var result =  0
//   var mz = 11         //  mz and mw = seed numbers for RNG program
var mz = Int.random(in: 18000 ..< 65535)  // = = = seem to be working = = = !!!
//    var mw = 11          //  making mz and mw = 0  output is all zero's
var mw = Int.random(in: 18000 ..< 65535)
//  Int.random  seems to generate new seeds !! Yes it works as seed !!!
for _ in 100...109  {    // 250 - 100 = 151 iterations of the - for in - loop -
    
    mz = 36969 * (mz & 65535) + (mz >> 16)
    mw = 18000 * (mw & 65535) + (mw >> 16)
    result = (mz << 16) + mw
    
    Nresult = result >> (32 + 8 + 3)  // truncates the number to 4 bits 0 - 17 ??
    // I think it is a signed number - ? - shrug -
    // and not a binary number being translated - ? -
    // +0, 0, -0, all count me thinks (0 - 15 + 2)
    
  //  print(" Nresult = \(Nresult)  - result =  \(result)")
    // - - -  see below for printout - Ok :)  - - -
}
// - - - End of - for loop - - -
//} - - - End  class  TestClass  // didn't work ?? for some reason !!
// = = =  End TestClass class  = = =



//  What’s new in Swift       = I think it's Swift 4.2 =
//  WWDC 2018 - session 401   = Apple Developer Video !!!

// var rng =  Int.random(in: 2 ..< 12)
// Used it in the above code  !!!  Makes for a good seed generator  !!!

for _ in 100...109 {
    let rng =  Int.random(in: 1 ..< 11)
   // print(rng)
    let fl = Float.random(in: 1 ..< 11)
    print(" ", rng, "-", fl)
}
// = = =  The above is a new RNG using Swift .random generators !!
// = = =  both Int and Float versions are available !!
// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =



// = = =  RNG Test of randomness  = = =
// - - - - - - - - - - - - - - -
var a1 = 0 ; var a2 = 0 ; var a3 = 0 ; var a4 = 0 ; var a5 = 0
var a6 = 0 ; var a7 = 0 ; var a8 = 0 ; var a9 = 0 ; var a10 = 0

for _ in 1 ... 1000 {
  
 let RNGTest = RNGT() // Int.random(in: 1 ... 10)   // testing randomness ??
// let RNGTest = RNGT()   // 1 - 10 at moment !!
    
    if RNGTest < 6 {
        if RNGTest == 1 { a1 += 1 }
        if RNGTest == 2 { a2 += 1 }
        if RNGTest == 3 { a3 += 1 }
        if RNGTest == 4 { a4 += 1 }
        if RNGTest == 5 { a5 += 1 }
    }
    else {
        if RNGTest == 6 { a6 += 1 }
        if RNGTest == 7 { a7 += 1 }
        if RNGTest == 8 { a8 += 1 }
        if RNGTest == 9 { a9 += 1 }
        if RNGTest == 10 { a10 += 1 }
    }
}
print(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, " - ",
      (a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10))

// for 1 to 1000 gives 87 - 124 int.random function
// for 1 to 100,000 gives a variation of 9911 - 10159 around 10000 !!
// for 100000 gives 9729 - 10248 another try !!
// for 100000 get 9836 - 10156  RNGT function
// for 100000 get 9798 - 10144  int.random function
// for 1,000,000 get 99348 - 100416  RNGT func
// for 1,000,000 get 99443 - 100144  int.random function
// for 10,000,000 get 998856 - 1002120  int.random
// = = =  End of RNG Test of Randomness  = = =
// = = = = = = = =
// = = =  Well IDK seems to be resonablely random for large sets !!!  = = =
// = = = = = = =
// = = = I think the RNTG func is a little less far off of optinum 10% per digit



